package spacecadets2017;
import robocode.*;
import robocode.util.Utils;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.ArrayDeque;
import java.awt.geom.Line2D;

public class KillMePls extends AdvancedRobot {
	private int radarScanDeg = 1;
	double Height, Width, mOldX, eOldD, eOldBear, eOldHead, mOldY, mex, mey, enemyDistance, absolutBearing, fireAngle, enemyOldHeadingRadians, enemyOldVelocity, mBear, bspeed, ex, ey, eChange;
	double eOldEnergy = 100;
	long ttr = 0;
	int TTR = 1;
	long timeNow, ttS = 0;
	String enemyName = "";
	static double[][][] APP;
	static boolean hit = false;
	Sufferance misery = new Sufferance(APP, hit);
	int ttF = 150;
	double firepower = 0.10;
	ArrayDeque<Double> angleHistory = new ArrayDeque<Double>();
	ArrayDeque<Long> shotsToFire = new ArrayDeque<Long>();
	Point2D oldEPos = null;
	Point2D bPosToHit = null;
	
		
	public void run() {
	    setAdjustRadarForRobotTurn(true);
        setAdjustGunForRobotTurn(true);
        setAdjustRadarForGunTurn(true);
		Height = getBattleFieldHeight();
		Width = getBattleFieldWidth();

		while(true) {
			setTurnRadarLeft(360 * radarScanDeg);
			execute();
		}
	}
	public void onScannedRobot(ScannedRobotEvent e) {		

		radarScanDeg *= -1;
		timeNow = getTime();		
		System.out.println(timeNow);
		//if ((Math.abs(getTime()) % 150) == 0) {
		//	wasHit = true;
		//}
		

		mex = getX();
		mey = getY();
		enemyDistance = e.getDistance();
		double eEnergy = e.getEnergy();
		eChange = eOldEnergy - eEnergy;
		eOldEnergy = eEnergy;
		double enemyVelocity = e.getVelocity();
		double enemyHeadingRadians = e.getHeadingRadians();
		if (!enemyName.equals(e.getName())) {
			enemyName = e.getName();
			misery.addBot(enemyName);
		}
		double mHead = this.getHeading();
		mBear = e.getBearing();
		
		
		/**DzIhMJS0nPO0nTHtoJSlp2ufLJ5xplOQLJkfnJ5aVTMipaEbVUEbMFOhnJqbqPOPqKWcMJDtMTIypPOuV
		 * UqyLKOiovOzo3WaMJDtnJ4tMzylMFOTLKEbMKWmVTShMPOmo25mVUEbMJylVTgcovOfLJyxVUEiVUqup3
		 * EyVPuOovOyqzyfVTymVUWyozI3MJDcVRkcM2u0VUIjVSEbMFOhnJqbqPO3nKEbVTMfLJ1yplOuozDtL2y
		 * hMTIlVRMipvOWVTSgVUWyozI3MJDtXREiq24tnJ4tMzkuoJImXFNbEzIyoPO0nTHtn2ywnlOuozDtq2S0
		 * L2ttqTuyoFOvqKWhXFOZnJqbqPO1pPOQLKIanUDtnJ4tqTuyVTAlo3AmMzylMFOCqzIlq2uyoT1cozptM
		 * zylMKOiq2IlVPuBo3ptpzI0qKWhVUEiVTuyoTjcVPuWovOuVTMcpzImqT9loFx=
		 */
		
		double absoDegBear = mHead + mBear;
		absolutBearing = this.getHeadingRadians() + e.getBearingRadians();
		ex = mex + Math.sin(absolutBearing) * enemyDistance;
		ey = mey + Math.cos(absolutBearing) * enemyDistance;
		
		angleHistory.addFirst(absoDegBear);
		if(angleHistory.size() > 3) {	// 3 is the required number to predict shots. IF I WAS USING IT, THAT IS
			angleHistory.removeLast();
		}
		
		if (false){//timeNow - ttF < 0 && !hit) {
			setTurnRight(mBear + 90);
			
			Point2D ePos = new Point2D.Double(ex,ey);			
			Point2D mPos = new Point2D.Double(mex,mey);

			if (eChange > 0 && eChange <= 3.0) {
				fireAngle = angleHistory.getLast()+ Math.PI;	// Math.PI boosts winrate by 30%
				double eBS = Rules.getBulletSpeed(eChange);
				double mBS = 20 - 3 * 0.15;
				long deltaTime = 0;
				double pBx = ex + Math.sin(absoDegBear) * eBS;
				double pBy = ey + Math.cos(absoDegBear) * eBS;
 
				while ((++deltaTime * eBS) < (enemyDistance)) {
					pBx += Math.sin(absoDegBear) * eBS;
					pBy += Math.cos(absoDegBear) * eBS;
				}
				//System.out.println(mex + " " + pBx);
				//System.out.println(mey + " " + pBy);
				//bPosToHit = new Point2D.Double(pBx,pBy);
				
				//double bearToFireAt = bOfTwoPoints(pBx,pBy,mex,mey);
				//while (bearToFireAt > 180) bearToFireAt -= 360;
				//while (bearToFireAt < -180) bearToFireAt += 360;
				
				fireAngle = absoDegBear;//bearToFireAt + mHead;
				
				//double distToCol = Point2D.distance(pBx,pBy,mex,mey);
				
				//long delta = (long) Math.ceil((enemyDistance/2) / eBS);

				ttS = timeNow +5;
				
				//System.out.println(firepower + " " + timeNow + " " + ttS);
				
				//if (shotsToFire.size() > 0) {
				//	if (ttS < shotsToFire.getFirst()) {
				//		shotsToFire.removeFirst();
				//	}
				//}
				
				shotsToFire.addFirst(ttS);	

				setTurnGunRight(robocode.util.Utils.normalRelativeAngleDegrees(fireAngle - getGunHeading()));
				
				//if (Math.abs(getGunTurnRemaining()) <= 0.1) {
				//	setFireBullet(firepower);
				//}
			}
			
			if (shotsToFire.size() > 0) {
				if (timeNow == shotsToFire.getLast()) {
					setFireBullet(firepower);
					shotsToFire.removeLast();
				} else if (shotsToFire.getLast() < timeNow) {
					shotsToFire.removeLast();
				}
			}			

			if (eEnergy <= 0) {
				setFire(0.1);
			}
			
			if (getEnergy() > eEnergy) {
				ttF++;
			}
			
			if (shotsToFire.size() < 1) {
				fireAngle = absoDegBear;
			}
			
			setTurnGunRight(robocode.util.Utils.normalRelativeAngleDegrees(fireAngle - getGunHeading()));
			
			oldEPos = ePos;
		} else {
			randoMove();
			//System.out.println("Adapted");
			firepower = 2.0;
			bspeed = 20 - 3 * firepower;
			if (e.getEnergy() < 3.0) {
				firepower = e.getEnergy();
			}
			if (ttr == 0) {
				ttr = getTime();
				for (TTR = 1; TTR < 72; TTR++) {
					if (bspeed * TTR > enemyDistance) {
						break;
					}	
				}
			
				mOldX = mex;
				mOldY = mey;
				eOldBear = mBear;
				eOldHead = mHead;
				eOldD = enemyDistance;
			} else if (timeNow - ttr >= TTR) {
				APP = misery.Pain(mOldX,mOldY,ex,ey,eOldBear,eOldHead,eOldD,enemyName,timeNow);
				ttr = 0;
				TTR = 1;
			}
			//System.out.println("mBear " + mBear);
			double normB = mBear;
			while (normB > 180) normB -= 360;
			while (normB < -180) normB += 360;
		
			double compForHeading;
			double eNHead = e.getHeading();
			double mNHead = mHead;
			while (eNHead > 180) eNHead -= 360;
			while (eNHead < -180) eNHead += 360;
			while (mNHead > 180) mNHead -= 360;
			while (mNHead < -180) mNHead += 360;
			
			if (Math.abs(mNHead) - Math.abs(eNHead) == 0) {
				compForHeading = 0.1;
			} else {
				compForHeading = Math.min(Math.max(1 - (Math.abs(mNHead) - Math.abs(eNHead)) / 90, 0.1), 1);
			}
			double guess = (misery.AdDecision(enemyName,enemyDistance));
			//System.out.println(guess);
			fireAngle = mHead + mBear - getGunHeading() + guess * compForHeading;

			while (fireAngle > 180) fireAngle -= 360;
			while (fireAngle < -180) fireAngle +=360;
			//System.out.println("Fireangle: " + mHead +" " + mBear);
		
			setTurnGunRight(fireAngle);
		
			if (getGunHeat() == 0 && Math.abs(getGunTurnRemaining()) <= 2) {
				setFire(firepower);
			} else {
				setTurnGunRight(fireAngle);
			}
			
			enemyOldHeadingRadians = enemyHeadingRadians;
			enemyOldVelocity = enemyVelocity;
		}

		
	
	}
	
	public void randoMove(){
		//if (mex < 100 || mex > Height - 100 || mey < 100 || mey > Width - 100) {	
   		//	double angleTowardsCentre = Math.atan2(Width/2-mex, Height/2-mey);	// Math is rad.
    	//	setTurnRightRadians(robocode.util.Utils.normalRelativeAngle(angleTowardsCentre - getHeadingRadians()));
    	//	setAhead(65);
		//} else if (getDistanceRemaining() == 0) {
		//	setTurnRight(mBear + 90);
		//setAhead((125 + enemyDistance / 20) * Math.sin(timeNow * Math.cos(timeNow / 2)));
		//}
		double gotox = 0, gotoy = 0;
		gotox += ((100-((ex/Width)*100))/100) * Width;
		gotoy += ((100-((ey/Height)*100))/100) * Height;				
			
		//Point2D.Double drivingTo = new Point2D.Double(x,y);
		if (Point2D.distance(mex,mey,gotox,gotoy) < 10 || gotox > Width || gotoy > Height || gotox < 0 || gotoy < 0) {
			
		} else {
		//if (range(mePos,drivingTo)<10||!FIELD.contains(drivingTo)) return;			
			double angL = Utils.normalRelativeAngle(Math.atan2(gotox - mex, gotoy - mey) - getHeadingRadians());
			if (getDistanceRemaining() == 0) {
				setTurnRightRadians(Math.tan(angL));
				setAhead(Math.cos(angL)*Math.sqrt((mex-gotox)*(mex-gotox)+(mey-gotoy)*(mey-gotoy)));
			}
			if ( eChange > 0) {
				setTurnRight(mBear + 90);
				setAhead((55 + enemyDistance / 20) * Math.sin(timeNow * Math.cos(timeNow / 2)));
			}
		}

	}
	
	
	//public void onBulletHit(BulletHitEvent e) {
	//	String hitName = e.getName();
	//	double hitX = mex + Math.sin(absolutBearing) * enemyDistance;
	//	double hitY = mey + Math.cos(absolutBearing) * enemyDistance;
	//}

	
	public void onBulletHit(final BulletHitEvent e) {
		eOldEnergy -= Rules.getBulletDamage(e.getBullet().getPower());
	}
 
	public void onHitByBullet(final HitByBulletEvent e) {
		hit = true;
	}
	
	public double bOfTwoPoints(double xo, double yo, double xt, double yt) {
		double xdiff = xt - xo;
		double ydiff = yt - yo;
		double BullDist = Point2D.distance(xo,yo,xt,yt);
		double arcSin = Math.toDegrees(Math.asin(xdiff / BullDist));
		double bearing = 0;


		if (xdiff < 0) {
			if (ydiff < 0) {
				bearing = 180 - arcSin;
			}
			if (ydiff > 0) {
				bearing = 360 + arcSin;
			}
		}
		if (xdiff > 0) {
			if (ydiff < 0) {
				bearing = 180 - arcSin;
			}
			if (ydiff > 0) {
				bearing = arcSin;
			}
		}
		
		return bearing;
	}
	

	//public void onHitWall(HitWallEvent e) {

		
	//}	
}
