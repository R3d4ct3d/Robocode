package spacecadets2017;
import java.util.HashMap;
//import java.awt.geom.Point2D;

/**IUqiVUEbnJ5aplO0olOho3EyVUEbMKWyYPOGMKWaMJShqP4tG25yVTymVUEbLKDtqTuypzHtnKZtoz8tp
 * 3IwnPO0nTyhMlOuplOuVT1coz9lVTEyqTScoP4tFJ5zo3WgLKEco24tnKZtqzywqT9lrF4tG25yVTAuoz
 * 5iqPOuozDtp2uiqJkxVT5iqPOxnKAgnKAmVTShrFOxLKEuVUIhqTyfVT9hMFOcplOcovOuVUOip2y0nJ9
 * hVUEiVTI2LJk1LKEyVTy0plOmnJqhnJMcL2ShL2HfVTShMPO0nTS0VT9hoUxtL29gMKZtq2y0nPObnJ5x
 * p2yanUDhVSAiVTSfoPOxMKEunJjtnKZtnJ1jo3W0LJ50VUIhqTyfVTAcpzA1oKA0LJ5wMKZtpzIhMTIlV
 * Ty0VUWyMUIhMTShqP4=
 */

public class Sufferance {
	//String eName;
	//double mX, mY, eX, eY, eV, aB, f, eD;
	static double[][][] APP;
	int robotCount = 0;
	HashMap<String, Integer> enemyBots = new HashMap<String, Integer>();
	
	/**ITuyVUIhnJMipz1mVT9zVUEbMFOWoKOypzyuoPOUqJSlMPOupzHtL2Sgo3IzoTSaMJDtnJ4to3WxMKVtq
	 * T8tpUWiqTIwqPO0nTIcpvO3MJSlMKWmVTW5VTucMTyhMlO0nTIgVTMlo20tp2yanUDhVSEbMFOjpzyhL2
	 * yjoTHtnKZtqTuuqPO3nTS0VUEbMFOyozIgrFOwLJ5ho3Dtp2IyVTuyVTAuoz5iqPOenJkfYvOHnTymVTy
	 * mVT5iqPO0nTHtq2S5VT9zVUEbMFOOMTIjqUImVRSmqTSlqTImYvOOVSAjLJAyVR1upzyhMrXNzKZtLKWg
	 * o3IlVTymVTWlnJqbqPO3nKEbVTuypzSfMUW5VUEbLKDtpUWiL2kunJ1mVTucplOxMKMiqTyiovO0olObn
	 * KZtD2uupUEypvOuozDtqTuyVTWyoT92MJDtEJ1jMKWipvOiMvOALJ5enJ5xYvOCqKVtpUWcozAcpTkyVT
	 * ymVUEbLKDtq2uuqPO0nTHtMJ5yoKxtL2ShVUAyMFjtnTHtq2yfoPOmo29hVTkyLKWhVUEiVTMyLKYvtXL
	 * t
	 */
	
	public Sufferance(double[][][] app, boolean hit) {
		if (hit){
			APP = app;
		} else {
			APP = new double[20][20][71];
		}
	}
	
	public void addBot(String eName) {
		if (!enemyBots.containsKey(eName)) {
			enemyBots.put(eName, robotCount);
			robotCount ++;
		}
	}
	
	public double[][][] Pain(double moldX, double moldY, double enewX, double enewY, double oldBear, double oldHead, double dist, String eName, long tim) {
		double xRelPos = enewX-moldX;
		double yRelPos = enewY-moldY;
		//double dist = Point2D.distance(moldX, moldY, enewX, enewY);
		double arcSin = Math.toDegrees(Math.asin(xRelPos / dist));
		double grossBearing = 0;
		double realBear = 0;
		int enemyDiffAngleThatWouldHit;
		double oldAdjBear = oldBear + oldHead % 360;

		if (xRelPos < 0) {
			if (yRelPos < 0) {
				grossBearing = 180 - arcSin;
			}
			if (yRelPos > 0) {
				grossBearing = 360 + arcSin;
			}
		}
		if (xRelPos > 0) {
			if (yRelPos < 0) {
				grossBearing = 180 - arcSin;
			}
			if (yRelPos > 0) {
				grossBearing = arcSin;
			}
		}
		//System.out.println("AbsRaw: " + grossBearing);
		
		realBear = (grossBearing) % 360;
		//System.out.println("OldabsBear: " + oldAdjBear);
		//System.out.println("realBear: " + realBear);
		//if (oldBear - realBear > 180) {
		//	realBear += 360;
		//} else if (realBear - oldBear > 180) {
		//	oldAdjBear = oldBear +=360;
		//}
		enemyDiffAngleThatWouldHit = (int) Math.round(realBear - oldAdjBear);
		while (enemyDiffAngleThatWouldHit > 180) enemyDiffAngleThatWouldHit -= 360;
		while (enemyDiffAngleThatWouldHit < -180) enemyDiffAngleThatWouldHit += 360;
		//System.out.println(oldAdjBear + " " + realBear);
		//int rBtoOneDeg =(int) Math.round(realBear);
		int rounDist = (Math.round(Math.round(dist) / 100));
		//System.out.println(eName + " " + rounDist + " " + enemyDiffAngleThatWouldHit);
		if (Math.abs(enemyDiffAngleThatWouldHit) <= 35) {
			APP[enemyBots.get(eName)][rounDist][(enemyDiffAngleThatWouldHit + 35)] += 1;
			System.out.println(APP[enemyBots.get(eName)][rounDist][(enemyDiffAngleThatWouldHit + 35)]);
			for (int i = 0; i < 71; i ++) {
				if (i != enemyDiffAngleThatWouldHit + 35) {
					//System.out.println("Sub" + i);
					if (APP[enemyBots.get(eName)][rounDist][i] != 0) {
						APP[enemyBots.get(eName)][rounDist][i] -= 0.25;
						System.out.println("Sub " + i + " " + APP[enemyBots.get(eName)][rounDist][i]);
					}
				}
			}
		}

		
		return APP;
		
	}
	
	
	public void rMrF(String eDead) {
		enemyBots.remove(eDead);
	}
	
	public void Cannot(String eDodger) {
		Integer infidel = enemyBots.get(eDodger);
		
		for (int i = 0; i < 10; i ++) {
			for (int j = 0; j < 71; j ++) {
				APP[infidel][i][j] = 0;
			}
		}
	}
	
	public double AdDecision(String eName, double dStance) {
		int mS = 0;
		int rounDist = Math.abs((Math.round(Math.round(dStance) / 100)));
		for (int i = 0; i < 71; i ++) {
			if (APP[enemyBots.get(eName)][rounDist][i] >= APP[enemyBots.get(eName)][rounDist][mS]) {
				mS = i;
			}
		}

		System.out.println(APP[enemyBots.get(eName)][rounDist][mS]);
		if (APP[enemyBots.get(eName)][rounDist][mS] == 0) {
			for (int j = 0; j < rounDist; j++) {
				for (int i = 0; i < 71; i ++) {
					if (APP[enemyBots.get(eName)][j][i] >= APP[enemyBots.get(eName)][rounDist][mS]) {
						mS = i;
					}
				}
			}

		} else {
			return (mS - 35);
		}
		System.out.println("Fallback 1");
		if (APP[enemyBots.get(eName)][rounDist][mS] == 0) {
			for (int j = rounDist; j < 10; j++) {
				for (int i = 0; i < 71; i ++) {
					if (APP[enemyBots.get(eName)][j][i] >= APP[enemyBots.get(eName)][rounDist][mS]) {
						mS = i;
					}
				}
			}
			if (APP[enemyBots.get(eName)][rounDist][mS] == 0) {
				return 0;
			} else {
				System.out.println("Fallback 2");
				return (mS - 35)*1.1;
			}

		} else {
			return (mS - 35)*0.9;
		}
	}
}
